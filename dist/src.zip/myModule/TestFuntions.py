def hello_world(name):
    print(f'Hello {name}!')